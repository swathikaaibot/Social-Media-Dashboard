import { createBrowserRouter } from "react-router";
import Home from "./pages/Home";
import ProfilePage from "./pages/ProfilePage";
import Notifications from "./pages/Notifications";
import Messages from "./pages/Messages";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/profile",
    Component: ProfilePage,
  },
  {
    path: "/notifications",
    Component: Notifications,
  },
  {
    path: "/messages",
    Component: Messages,
  },
]);
