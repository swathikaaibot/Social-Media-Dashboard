import { useEffect } from 'react';
import { RouterProvider } from 'react-router';
import { ThemeProvider } from './context/ThemeContext';
import { initializeMockData } from './utils/mockData';
import { router } from './routes';
import Header from './components/Header';

export default function App() {
  useEffect(() => {
    // Initialize mock data on app start
    initializeMockData();
  }, []);

  return (
    <ThemeProvider>
      <div className="min-h-screen bg-[#f0f2f5] dark-mode:bg-[#18191a] transition-colors duration-300">
        <Header />
        <main className="min-h-[calc(100vh-64px)] pt-16">
          <RouterProvider router={router} />
        </main>
      </div>
    </ThemeProvider>
  );
}
