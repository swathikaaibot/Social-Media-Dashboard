import React, { useState, useEffect } from 'react';
import Notification from '../../components/Notification';
import { api } from '../../utils/api';
import { Notification as NotificationType } from '../../utils/mockData';

function Notifications() {
  const [notifications, setNotifications] = useState<NotificationType[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadNotifications();
  }, []);

  const loadNotifications = async () => {
    setLoading(true);
    const fetchedNotifications = await api.getNotifications();
    setNotifications(fetchedNotifications);
    setLoading(false);
  };

  const handleMarkAsRead = async (notificationId: number) => {
    await api.markNotificationAsRead(notificationId);
    setNotifications(notifications.map(n =>
      n.id === notificationId ? { ...n, read: true } : n
    ));
  };

  const handleDelete = async (notificationId: number) => {
    await api.deleteNotification(notificationId);
    setNotifications(notifications.filter(n => n.id !== notificationId));
  };

  const markAllAsRead = async () => {
    for (const notification of notifications) {
      await api.markNotificationAsRead(notification.id);
    }
    setNotifications(notifications.map(n => ({ ...n, read: true })));
  };

  if (loading) {
    return <div className="text-center p-8 text-[#65676b]">Loading...</div>;
  }

  return (
    <div className="max-w-[800px] mx-auto p-4 md:p-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-[#050505] dark-mode:text-[#e4e6eb] m-0">Notifications</h2>
        {notifications.some(n => !n.read) && (
          <button
            className="px-4 py-2 rounded-lg bg-[#e4e6eb] dark-mode:bg-[#3a3b3c] text-[#050505] dark-mode:text-[#e4e6eb] border-none cursor-pointer hover:bg-[#d8dadf] dark-mode:hover:bg-[#4e4f50] transition-all duration-300"
            onClick={markAllAsRead}
          >
            Mark all as read
          </button>
        )}
      </div>

      {notifications.length === 0 ? (
        <div className="bg-white dark-mode:bg-[#242526] rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.1)] dark-mode:shadow-[0_2px_8px_rgba(0,0,0,0.3)] p-12 text-center text-[#65676b]">
          <p>No notifications yet</p>
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          {notifications.map(notification => (
            <Notification
              key={notification.id}
              notification={notification}
              onMarkAsRead={handleMarkAsRead}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default Notifications;