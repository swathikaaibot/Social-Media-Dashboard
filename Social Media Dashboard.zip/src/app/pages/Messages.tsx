import React, { useState } from 'react';

interface Chat {
  id: number;
  user: {
    name: string;
    avatar: string;
    online: boolean;
  };
  lastMessage: string;
  time: string;
  unread: number;
}

interface Message {
  id: number;
  text: string;
  sender: string;
  time: string;
}

function Messages() {
  const [selectedChat, setSelectedChat] = useState<number | null>(null);
  const [messageText, setMessageText] = useState('');
  const [chats] = useState<Chat[]>([
    {
      id: 1,
      user: {
        name: 'Alice Johnson',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop',
        online: true
      },
      lastMessage: 'Hey, how are you?',
      time: '5 min ago',
      unread: 2
    },
    {
      id: 2,
      user: {
        name: 'Bob Smith',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop',
        online: false
      },
      lastMessage: 'See you tomorrow!',
      time: '1 hour ago',
      unread: 0
    }
  ]);

  const [messages, setMessages] = useState<{ [key: number]: Message[] }>({
    1: [
      { id: 1, text: 'Hey, how are you?', sender: 'Alice', time: '10:30 AM' },
      { id: 2, text: "I'm good, thanks!", sender: 'You', time: '10:32 AM' }
    ],
    2: [
      { id: 1, text: 'See you tomorrow!', sender: 'Bob', time: '9:00 AM' }
    ]
  });

  const handleSendMessage = () => {
    if (messageText.trim() && selectedChat) {
      const newMessage: Message = {
        id: Date.now(),
        text: messageText,
        sender: 'You',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages({
        ...messages,
        [selectedChat]: [...(messages[selectedChat] || []), newMessage]
      });
      setMessageText('');
    }
  };

  return (
    <div className="grid lg:grid-cols-[350px_1fr] grid-cols-1 gap-4 max-w-[1200px] mx-auto p-4 md:p-8 h-[calc(100vh-80px)]">
      <div className="bg-white dark-mode:bg-[#242526] rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.1)] dark-mode:shadow-[0_2px_8px_rgba(0,0,0,0.3)] flex flex-col h-full overflow-hidden p-6">
        <h3 className="m-0 mb-4 text-[#050505] dark-mode:text-[#e4e6eb]">Chats</h3>
        <div className="overflow-y-auto flex-1">
          {chats.map(chat => (
            <div
              key={chat.id}
              className={`flex items-center gap-4 p-4 cursor-pointer rounded-lg transition-colors ${
                selectedChat === chat.id 
                  ? 'bg-[#e7f3ff] dark-mode:bg-[#263951]' 
                  : 'hover:bg-[#f0f2f5] dark-mode:hover:bg-[#3a3b3c]'
              }`}
              onClick={() => setSelectedChat(chat.id)}
            >
              <div className="relative">
                <img 
                  src={chat.user.avatar} 
                  alt={chat.user.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                {chat.user.online && (
                  <span className="absolute bottom-0.5 right-0.5 w-3 h-3 bg-[#31a24c] rounded-full border-2 border-white"></span>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="m-0 mb-1 text-[#050505] dark-mode:text-[#e4e6eb]">{chat.user.name}</h4>
                <p className="m-0 text-[#65676b] text-sm whitespace-nowrap overflow-hidden text-ellipsis">{chat.lastMessage}</p>
              </div>
              <div className="flex flex-col items-end gap-1">
                <span className="text-[#65676b] text-xs">{chat.time}</span>
                {chat.unread > 0 && (
                  <span className="bg-[#1877f2] text-white text-xs px-1.5 py-0.5 rounded-full">{chat.unread}</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white dark-mode:bg-[#242526] rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.1)] dark-mode:shadow-[0_2px_8px_rgba(0,0,0,0.3)] flex flex-col h-full p-0 overflow-hidden">
        {selectedChat ? (
          <>
            <div className="p-4 border-b border-[#e4e6eb] dark-mode:border-[#3e4042]">
              <h4 className="m-0 text-[#050505] dark-mode:text-[#e4e6eb]">
                {chats.find(c => c.id === selectedChat)?.user.name}
              </h4>
            </div>

            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
              {messages[selectedChat]?.map(message => (
                <div
                  key={message.id}
                  className={`flex mb-2 ${message.sender === 'You' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-[70%] p-3 rounded-xl relative ${
                    message.sender === 'You'
                      ? 'bg-[#1877f2] text-white'
                      : 'bg-[#f0f2f5] dark-mode:bg-[#3a3b3c] text-[#050505] dark-mode:text-[#e4e6eb]'
                  }`}>
                    <p className="m-0">{message.text}</p>
                    <span className="text-xs opacity-70 mt-1 block">{message.time}</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-4 border-t border-[#e4e6eb] dark-mode:border-[#3e4042] flex gap-4">
              <input
                type="text"
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                placeholder="Type a message..."
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                className="flex-1 p-3 border border-[#e4e6eb] dark-mode:border-[#4e4f50] dark-mode:bg-[#3a3b3c] dark-mode:text-[#e4e6eb] rounded-full focus:outline-none focus:border-[#1877f2]"
              />
              <button
                onClick={handleSendMessage}
                disabled={!messageText.trim()}
                className="px-6 py-3 rounded-lg bg-[#1877f2] text-white border-none cursor-pointer hover:bg-[#166fe5] transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Send
              </button>
            </div>
          </>
        ) : (
          <div className="flex items-center justify-center h-full text-[#65676b]">
            <p>Select a chat to start messaging</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default Messages;