import React, { useState, useEffect } from 'react';
import Post from '../../components/Post';
import Profile from '../../components/Profile';
import { api } from '../../utils/api';
import { mockUser, Post as PostType } from '../../utils/mockData';

function Home() {
  const [posts, setPosts] = useState<PostType[]>([]);
  const [loading, setLoading] = useState(true);
  const [newPost, setNewPost] = useState('');
  const [user] = useState(mockUser);

  useEffect(() => {
    loadPosts();
  }, []);

  const loadPosts = async () => {
    setLoading(true);
    const fetchedPosts = await api.getPosts();
    setPosts(fetchedPosts);
    setLoading(false);
  };

  const handleCreatePost = async () => {
    if (newPost.trim()) {
      const post = {
        author: {
          name: user.name,
          avatar: user.avatar,
        },
        content: newPost,
        likes: 0,
        comments: []
      };

      const createdPost = await api.createPost(post);
      setPosts([createdPost, ...posts]);
      setNewPost('');
    }
  };

  const handleLike = async (postId: number) => {
    await api.likePost(postId);
    setPosts(posts.map(post => {
      if (post.id === postId) {
        return { ...post, likes: post.likes + 1 };
      }
      return post;
    }));
  };

  const handleComment = async (postId: number, comment: string) => {
    await api.addComment(postId, comment);
    setPosts(posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          comments: [...(post.comments || []), {
            id: Date.now(),
            user: 'Current User',
            text: comment
          }]
        };
      }
      return post;
    }));
  };

  if (loading) {
    return <div className="text-center p-8 text-[#65676b]">Loading...</div>;
  }

  return (
    <div className="grid lg:grid-cols-[300px_1fr] grid-cols-1 gap-8 max-w-[1200px] mx-auto p-4 md:p-8">
      <div className="lg:sticky lg:top-20 h-fit">
        <Profile user={user} isEditable={false} />
      </div>

      <div className="min-w-0">
        <div className="bg-white dark-mode:bg-[#242526] rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.1)] dark-mode:shadow-[0_2px_8px_rgba(0,0,0,0.3)] p-6 mb-4">
          <textarea
            value={newPost}
            onChange={(e) => setNewPost(e.target.value)}
            placeholder="What's on your mind?"
            className="w-full min-h-[100px] p-4 border border-[#e4e6eb] dark-mode:border-[#4e4f50] dark-mode:bg-[#3a3b3c] dark-mode:text-[#e4e6eb] rounded-lg mb-4 font-sans resize-y focus:outline-none focus:border-[#1877f2]"
          />
          <button
            onClick={handleCreatePost}
            disabled={!newPost.trim()}
            className="w-full px-6 py-3 rounded-lg bg-[#1877f2] text-white border-none cursor-pointer hover:bg-[#166fe5] transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Post
          </button>
        </div>

        <div className="flex flex-col gap-4">
          {posts.length === 0 ? (
            <div className="bg-white dark-mode:bg-[#242526] rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.1)] dark-mode:shadow-[0_2px_8px_rgba(0,0,0,0.3)] p-12 text-center text-[#65676b]">
              <p>No posts yet. Be the first to post!</p>
            </div>
          ) : (
            posts.map(post => (
              <Post
                key={post.id}
                post={post}
                onLike={handleLike}
                onComment={handleComment}
              />
            ))
          )}
        </div>
      </div>
    </div>
  );
}

export default Home;