import React, { useState, useEffect } from 'react';
import Profile from '../../components/Profile';
import Post from '../../components/Post';
import { api } from '../../utils/api';
import { mockUser, Post as PostType } from '../../utils/mockData';

function ProfilePage() {
  const [user, setUser] = useState(mockUser);
  const [userPosts, setUserPosts] = useState<PostType[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    setLoading(true);
    const posts = await api.getPosts();
    // Filter posts by current user
    const filteredPosts = posts.filter(post => post.author.name === user.name);
    setUserPosts(filteredPosts);
    setLoading(false);
  };

  const handleLike = async (postId: number) => {
    await api.likePost(postId);
    setUserPosts(userPosts.map(post => {
      if (post.id === postId) {
        return { ...post, likes: post.likes + 1 };
      }
      return post;
    }));
  };

  if (loading) {
    return <div className="text-center p-8 text-[#65676b]">Loading...</div>;
  }

  return (
    <div className="max-w-[1200px] mx-auto p-4 md:p-8">
      <Profile user={user} isEditable={true} />

      <div className="mt-8">
        <h3 className="mb-4 text-[#050505] dark-mode:text-[#e4e6eb]">Your Posts</h3>
        {userPosts.length === 0 ? (
          <div className="bg-white dark-mode:bg-[#242526] rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.1)] dark-mode:shadow-[0_2px_8px_rgba(0,0,0,0.3)] p-12 text-center text-[#65676b]">
            <p>You haven't posted anything yet.</p>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {userPosts.map(post => (
              <Post
                key={post.id}
                post={post}
                onLike={handleLike}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default ProfilePage;