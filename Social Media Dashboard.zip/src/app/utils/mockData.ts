// Initial mock data for localStorage
export const initializeMockData = () => {
  if (!localStorage.getItem('posts')) {
    const mockPosts = [
      {
        id: 1,
        author: {
          name: "John Doe",
          avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop"
        },
        content: "Just finished building my first React app! 🚀",
        image: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=600&h=400&fit=crop",
        likes: 42,
        time: "2 hours ago",
        comments: [
          { id: 1, user: "Jane", text: "Great job!" },
          { id: 2, user: "Bob", text: "Awesome work!" }
        ]
      },
      {
        id: 2,
        author: {
          name: "Jane Smith",
          avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop"
        },
        content: "Beautiful sunset today! 🌅",
        image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=400&fit=crop",
        likes: 28,
        time: "5 hours ago",
        comments: []
      }
    ];
    localStorage.setItem('posts', JSON.stringify(mockPosts));
  }

  if (!localStorage.getItem('profile')) {
    const mockUser = {
      name: "John Doe",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop",
      coverImage: "https://images.unsplash.com/photo-1557683316-973673baf926?w=1200&h=400&fit=crop",
      bio: "Frontend developer passionate about React",
      posts: 45,
      followers: 1234,
      following: 567
    };
    localStorage.setItem('profile', JSON.stringify(mockUser));
  }

  if (!localStorage.getItem('notifications')) {
    const mockNotifications = [
      {
        id: 1,
        type: 'like',
        user: 'Jane Smith',
        action: 'liked your post',
        time: '5 min ago',
        read: false
      },
      {
        id: 2,
        type: 'comment',
        user: 'Bob Johnson',
        action: 'commented on your post',
        time: '1 hour ago',
        read: false
      },
      {
        id: 3,
        type: 'follow',
        user: 'Alice Brown',
        action: 'started following you',
        time: '2 hours ago',
        read: true
      }
    ];
    localStorage.setItem('notifications', JSON.stringify(mockNotifications));
  }
};

// Export initialized data
export const mockUser = typeof window !== 'undefined' 
  ? JSON.parse(localStorage.getItem('profile') || 'null') || {
      name: "John Doe",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop",
      coverImage: "https://images.unsplash.com/photo-1557683316-973673baf926?w=1200&h=400&fit=crop",
      bio: "Frontend developer passionate about React",
      posts: 45,
      followers: 1234,
      following: 567
    }
  : {
      name: "John Doe",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop",
      coverImage: "https://images.unsplash.com/photo-1557683316-973673baf926?w=1200&h=400&fit=crop",
      bio: "Frontend developer passionate about React",
      posts: 45,
      followers: 1234,
      following: 567
    };

export interface Post {
  id: number;
  author: {
    name: string;
    avatar: string;
  };
  content: string;
  image?: string;
  likes: number;
  time: string;
  comments: Comment[];
}

export interface Comment {
  id: number;
  user: string;
  text: string;
}

export interface User {
  name: string;
  avatar: string;
  coverImage: string;
  bio: string;
  posts: number;
  followers: number;
  following: number;
}

export interface Notification {
  id: number;
  type: 'like' | 'comment' | 'follow' | 'share';
  user: string;
  action: string;
  time: string;
  read: boolean;
}
