import { Post, Comment, User, Notification } from './mockData';

// Simulate API calls with mock data
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const api = {
  // Posts
  async getPosts(): Promise<Post[]> {
    await delay(1000);
    const posts = JSON.parse(localStorage.getItem('posts') || '[]');
    return posts;
  },

  async createPost(post: Partial<Post>): Promise<Post> {
    await delay(500);
    const posts: Post[] = JSON.parse(localStorage.getItem('posts') || '[]');
    const newPost: Post = {
      ...post,
      id: Date.now(),
      time: 'Just now',
      comments: [],
      likes: post.likes || 0,
      author: post.author || { name: '', avatar: '' },
      content: post.content || ''
    } as Post;
    posts.unshift(newPost);
    localStorage.setItem('posts', JSON.stringify(posts));
    return newPost;
  },

  async likePost(postId: number): Promise<Post | null> {
    await delay(200);
    const posts: Post[] = JSON.parse(localStorage.getItem('posts') || '[]');
    const post = posts.find(p => p.id === postId);
    if (post) {
      post.likes += 1;
      localStorage.setItem('posts', JSON.stringify(posts));
    }
    return post || null;
  },

  async addComment(postId: number, comment: string): Promise<Comment | null> {
    await delay(300);
    const posts: Post[] = JSON.parse(localStorage.getItem('posts') || '[]');
    const post = posts.find(p => p.id === postId);
    if (post) {
      const newComment: Comment = {
        id: Date.now(),
        user: 'Current User',
        text: comment
      };
      post.comments.push(newComment);
      localStorage.setItem('posts', JSON.stringify(posts));
      return newComment;
    }
    return null;
  },

  // Profile
  async getProfile(): Promise<User | null> {
    await delay(500);
    const profile = JSON.parse(localStorage.getItem('profile') || 'null');
    return profile;
  },

  async updateProfile(profileData: User): Promise<User> {
    await delay(500);
    localStorage.setItem('profile', JSON.stringify(profileData));
    return profileData;
  },

  // Notifications
  async getNotifications(): Promise<Notification[]> {
    await delay(500);
    const notifications = JSON.parse(localStorage.getItem('notifications') || '[]');
    return notifications;
  },

  async markNotificationAsRead(notificationId: number): Promise<Notification | null> {
    await delay(200);
    const notifications: Notification[] = JSON.parse(localStorage.getItem('notifications') || '[]');
    const notification = notifications.find(n => n.id === notificationId);
    if (notification) {
      notification.read = true;
      localStorage.setItem('notifications', JSON.stringify(notifications));
    }
    return notification || null;
  },

  async deleteNotification(notificationId: number): Promise<boolean> {
    await delay(200);
    let notifications: Notification[] = JSON.parse(localStorage.getItem('notifications') || '[]');
    notifications = notifications.filter(n => n.id !== notificationId);
    localStorage.setItem('notifications', JSON.stringify(notifications));
    return true;
  }
};
