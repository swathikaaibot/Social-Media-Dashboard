import React, { useState } from 'react';
import Modal from '../common/Modal';
import { User } from '../../utils/mockData';

interface ProfileProps {
  user: User;
  isEditable?: boolean;
}

function Profile({ user, isEditable = false }: ProfileProps) {
  const [showEditModal, setShowEditModal] = useState(false);
  const [userData, setUserData] = useState(user);

  const handleEditProfile = () => {
    setShowEditModal(true);
  };

  return (
    <>
      <div className="bg-white dark-mode:bg-[#242526] rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.1)] dark-mode:shadow-[0_2px_8px_rgba(0,0,0,0.3)] overflow-hidden">
        <div className="relative h-[200px]">
          <img 
            src={userData.coverImage} 
            alt="Cover" 
            className="w-full h-full object-cover"
          />
        </div>

        <div className="p-6">
          <img
            src={userData.avatar}
            alt={userData.name}
            className="w-[120px] h-[120px] rounded-full border-4 border-white dark-mode:border-[#242526] object-cover -mt-[80px] mb-4"
          />

          <div>
            <h2 className="m-0 mb-2 text-[#050505] dark-mode:text-[#e4e6eb]">{userData.name}</h2>
            <p className="text-[#65676b] dark-mode:text-[#b0b3b8] mb-4">{userData.bio}</p>

            <div className="flex gap-8 mb-4">
              <div className="text-center">
                <span className="block text-xl font-bold text-[#050505] dark-mode:text-[#e4e6eb]">{userData.posts}</span>
                <span className="text-sm text-[#65676b] dark-mode:text-[#b0b3b8]">Posts</span>
              </div>
              <div className="text-center">
                <span className="block text-xl font-bold text-[#050505] dark-mode:text-[#e4e6eb]">{userData.followers}</span>
                <span className="text-sm text-[#65676b] dark-mode:text-[#b0b3b8]">Followers</span>
              </div>
              <div className="text-center">
                <span className="block text-xl font-bold text-[#050505] dark-mode:text-[#e4e6eb]">{userData.following}</span>
                <span className="text-sm text-[#65676b] dark-mode:text-[#b0b3b8]">Following</span>
              </div>
            </div>

            {isEditable && (
              <button
                className="px-4 py-2 rounded-lg bg-[#1877f2] text-white border-none cursor-pointer hover:bg-[#166fe5] transition-all duration-300"
                onClick={handleEditProfile}
              >
                Edit Profile
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Edit Profile Modal */}
      <Modal
        isOpen={showEditModal}
        onClose={() => setShowEditModal(false)}
        title="Edit Profile"
      >
        <div className="flex flex-col gap-4">
          <div className="flex flex-col gap-2">
            <label className="font-semibold text-[#050505] dark-mode:text-[#e4e6eb]">Name</label>
            <input
              type="text"
              value={userData.name}
              onChange={(e) => setUserData({...userData, name: e.target.value})}
              className="p-3 border border-[#e4e6eb] dark-mode:border-[#4e4f50] dark-mode:bg-[#3a3b3c] dark-mode:text-[#e4e6eb] rounded-lg focus:outline-none focus:border-[#1877f2]"
            />
          </div>
          <div className="flex flex-col gap-2">
            <label className="font-semibold text-[#050505] dark-mode:text-[#e4e6eb]">Bio</label>
            <textarea
              value={userData.bio}
              onChange={(e) => setUserData({...userData, bio: e.target.value})}
              rows={3}
              className="p-3 border border-[#e4e6eb] dark-mode:border-[#4e4f50] dark-mode:bg-[#3a3b3c] dark-mode:text-[#e4e6eb] rounded-lg focus:outline-none focus:border-[#1877f2]"
            />
          </div>
          <button
            className="px-6 py-3 rounded-lg bg-[#1877f2] text-white border-none cursor-pointer hover:bg-[#166fe5] transition-all duration-300"
            onClick={() => setShowEditModal(false)}
          >
            Save Changes
          </button>
        </div>
      </Modal>
    </>
  );
}

export default Profile;
