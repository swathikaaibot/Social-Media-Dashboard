import React, { useState } from 'react';
import { Notification as NotificationType } from '../../utils/mockData';

interface NotificationProps {
  notification: NotificationType;
  onMarkAsRead?: (id: number) => void;
  onDelete: (id: number) => void;
}

function Notification({ notification, onMarkAsRead, onDelete }: NotificationProps) {
  const [isRead, setIsRead] = useState(notification.read);

  const handleMarkAsRead = () => {
    setIsRead(true);
    if (onMarkAsRead) onMarkAsRead(notification.id);
  };

  return (
    <div className={`bg-white dark-mode:bg-[#242526] rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.1)] dark-mode:shadow-[0_2px_8px_rgba(0,0,0,0.3)] p-4 md:p-6 mb-2 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 transition-opacity duration-300 ${isRead ? 'opacity-60' : ''}`}>
      <div className="flex gap-4 items-center flex-1">
        <div className="text-2xl">
          {notification.type === 'like' && '❤️'}
          {notification.type === 'comment' && '💬'}
          {notification.type === 'follow' && '👤'}
          {notification.type === 'share' && '↪️'}
        </div>

        <div className="flex-1">
          <p className="m-0 mb-1 text-[#050505] dark-mode:text-[#e4e6eb]">
            <strong>{notification.user}</strong> {notification.action}
          </p>
          <span className="text-[#65676b] text-sm">{notification.time}</span>
        </div>
      </div>

      <div className="flex gap-2 w-full sm:w-auto">
        {!isRead && (
          <button
            className="px-4 py-2 rounded-lg bg-[#e4e6eb] dark-mode:bg-[#3a3b3c] text-[#050505] dark-mode:text-[#e4e6eb] border-none cursor-pointer hover:bg-[#d8dadf] dark-mode:hover:bg-[#4e4f50] transition-all duration-300"
            onClick={handleMarkAsRead}
          >
            Mark as Read
          </button>
        )}
        <button
          className="px-4 py-2 rounded-lg bg-[#dc3545] text-white border-none cursor-pointer hover:bg-[#c82333] transition-all duration-300"
          onClick={() => onDelete(notification.id)}
        >
          Delete
        </button>
      </div>
    </div>
  );
}

export default Notification;