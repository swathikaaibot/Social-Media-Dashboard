import React, { useEffect, ReactNode } from 'react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
}

function Modal({ isOpen, onClose, title, children }: ModalProps) {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-black/50 flex justify-center items-center z-[2000] animate-[fadeIn_0.3s_ease]"
      onClick={onClose}
    >
      <div 
        className="bg-white dark-mode:bg-[#242526] rounded-xl w-[90%] max-w-[500px] max-h-[90vh] overflow-y-auto animate-[slideUp_0.3s_ease]"
        onClick={e => e.stopPropagation()}
      >
        <div className="p-6 border-b border-[#e4e6eb] dark-mode:border-[#3e4042] flex justify-between items-center">
          <h3 className="m-0 text-[#050505] dark-mode:text-[#e4e6eb]">{title}</h3>
          <button 
            className="bg-transparent border-none text-2xl cursor-pointer text-[#65676b] dark-mode:text-[#b0b3b8] p-2 leading-none hover:text-[#050505] dark-mode:hover:text-[#e4e6eb]"
            onClick={onClose}
          >
            ×
          </button>
        </div>
        <div className="p-6">
          {children}
        </div>
        <div className="p-6 border-t border-[#e4e6eb] dark-mode:border-[#3e4042] flex justify-end">
          <button
            className="px-6 py-3 rounded-lg bg-[#e4e6eb] dark-mode:bg-[#3a3b3c] text-[#050505] dark-mode:text-[#e4e6eb] border-none cursor-pointer hover:bg-[#d8dadf] dark-mode:hover:bg-[#4e4f50] transition-all duration-300"
            onClick={onClose}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

export default Modal;
