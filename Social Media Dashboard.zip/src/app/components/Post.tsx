import React, { useState } from 'react';
import Modal from '../common/Modal';
import { Post as PostType } from '../../utils/mockData';

interface PostProps {
  post: PostType;
  onLike?: (postId: number) => void;
  onComment?: (postId: number, comment: string) => void;
}

function Post({ post, onLike, onComment }: PostProps) {
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [isLiked, setIsLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(post.likes);
  const [showShareModal, setShowShareModal] = useState(false);

  const handleLike = () => {
    if (isLiked) {
      setLikesCount(likesCount - 1);
    } else {
      setLikesCount(likesCount + 1);
    }
    setIsLiked(!isLiked);
    if (onLike) onLike(post.id);
  };

  const handleComment = () => {
    if (commentText.trim()) {
      if (onComment) onComment(post.id, commentText);
      setCommentText('');
    }
  };

  return (
    <>
      <div className="bg-white dark-mode:bg-[#242526] rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.1)] dark-mode:shadow-[0_2px_8px_rgba(0,0,0,0.3)] overflow-hidden p-6 mb-4">
        {/* Post Header */}
        <div className="flex items-center gap-4 mb-4">
          <img
            src={post.author.avatar}
            alt={post.author.name}
            className="w-10 h-10 rounded-full object-cover"
          />
          <div>
            <h4 className="m-0 text-[#050505] dark-mode:text-[#e4e6eb]">{post.author.name}</h4>
            <span className="text-[#65676b] text-sm">{post.time}</span>
          </div>
        </div>

        {/* Post Content */}
        <p className="mb-4 leading-relaxed text-[#050505] dark-mode:text-[#e4e6eb]">{post.content}</p>

        {post.image && (
          <img
            src={post.image}
            alt="Post content"
            className="w-full max-h-[400px] object-cover rounded-lg mb-4"
          />
        )}

        {/* Post Stats */}
        <div className="flex gap-4 py-2 border-t border-b border-[#e4e6eb] dark-mode:border-[#3e4042] mb-2 text-[#65676b] text-sm">
          <span>❤️ {likesCount} likes</span>
          <span>💬 {post.comments?.length || 0} comments</span>
        </div>

        {/* Post Actions */}
        <div className="flex gap-2 mb-4">
          <button
            className={`px-4 py-2 rounded-lg border-none cursor-pointer transition-all duration-300 ${
              isLiked 
                ? 'bg-[#1877f2] text-white' 
                : 'bg-[#e4e6eb] dark-mode:bg-[#3a3b3c] text-[#050505] dark-mode:text-[#e4e6eb] hover:bg-[#d8dadf] dark-mode:hover:bg-[#4e4f50]'
            }`}
            onClick={handleLike}
          >
            ❤️ Like
          </button>
          <button
            className="px-4 py-2 rounded-lg bg-[#e4e6eb] dark-mode:bg-[#3a3b3c] text-[#050505] dark-mode:text-[#e4e6eb] border-none cursor-pointer hover:bg-[#d8dadf] dark-mode:hover:bg-[#4e4f50] transition-all duration-300"
            onClick={() => setShowComments(!showComments)}
          >
            💬 Comment
          </button>
          <button
            className="px-4 py-2 rounded-lg bg-[#e4e6eb] dark-mode:bg-[#3a3b3c] text-[#050505] dark-mode:text-[#e4e6eb] border-none cursor-pointer hover:bg-[#d8dadf] dark-mode:hover:bg-[#4e4f50] transition-all duration-300"
            onClick={() => setShowShareModal(true)}
          >
            ↪️ Share
          </button>
        </div>

        {/* Comments Section */}
        {showComments && (
          <div className="border-t border-[#e4e6eb] dark-mode:border-[#3e4042] pt-4">
            {post.comments?.map(comment => (
              <div 
                key={comment.id} 
                className="p-2 bg-[#f0f2f5] dark-mode:bg-[#3a3b3c] dark-mode:text-[#e4e6eb] rounded-lg mb-2 text-sm"
              >
                <strong>{comment.user}:</strong> {comment.text}
              </div>
            ))}

            {/* Add Comment */}
            <div className="flex gap-2 mt-4">
              <input
                type="text"
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="Write a comment..."
                className="flex-1 p-2 border border-[#e4e6eb] dark-mode:border-[#4e4f50] dark-mode:bg-[#3a3b3c] dark-mode:text-[#e4e6eb] rounded-full text-sm focus:outline-none focus:border-[#1877f2]"
              />
              <button
                className="px-4 py-2 rounded-lg bg-[#1877f2] text-white border-none cursor-pointer hover:bg-[#166fe5] transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                onClick={handleComment}
                disabled={!commentText.trim()}
              >
                Post
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Share Modal */}
      <Modal
        isOpen={showShareModal}
        onClose={() => setShowShareModal(false)}
        title="Share Post"
      >
        <div className="flex flex-col gap-2">
          <button className="flex items-center gap-4 p-4 border-none bg-transparent rounded-lg cursor-pointer w-full text-left transition-colors hover:bg-[#f0f2f5] dark-mode:hover:bg-[#3a3b3c]">
            <span>📱</span> Share to Feed
          </button>
          <button className="flex items-center gap-4 p-4 border-none bg-transparent rounded-lg cursor-pointer w-full text-left transition-colors hover:bg-[#f0f2f5] dark-mode:hover:bg-[#3a3b3c]">
            <span>💬</span> Share in Message
          </button>
          <button className="flex items-center gap-4 p-4 border-none bg-transparent rounded-lg cursor-pointer w-full text-left transition-colors hover:bg-[#f0f2f5] dark-mode:hover:bg-[#3a3b3c]">
            <span>🔗</span> Copy Link
          </button>
        </div>
      </Modal>
    </>
  );
}

export default Post;
