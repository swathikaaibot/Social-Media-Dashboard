import React, { useState } from 'react';
import { Link } from 'react-router';
import { useTheme } from '../../context/ThemeContext';

function Header() {
  const { darkMode, toggleDarkMode } = useTheme();
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 bg-white dark-mode:bg-[#242526] shadow-[0_2px_8px_rgba(0,0,0,0.1)] dark-mode:shadow-[0_2px_8px_rgba(0,0,0,0.3)] z-[1000] h-16">
      <div className="max-w-[1400px] mx-auto px-4 md:px-8 h-full flex items-center justify-between">
        <div>
          <Link to="/" className="no-underline">
            <h2 className="m-0 text-[#1877f2] dark-mode:text-[#1877f2] text-lg md:text-xl">📱 SocialDash</h2>
          </Link>
        </div>

        <nav className="hidden md:flex gap-4 lg:gap-8 items-center">
          <Link to="/" className="no-underline text-[#050505] dark-mode:text-[#e4e6eb] hover:text-[#1877f2] dark-mode:hover:text-[#1877f2] transition-colors">
            Home
          </Link>
          <Link to="/profile" className="no-underline text-[#050505] dark-mode:text-[#e4e6eb] hover:text-[#1877f2] dark-mode:hover:text-[#1877f2] transition-colors">
            Profile
          </Link>
          <Link to="/notifications" className="no-underline text-[#050505] dark-mode:text-[#e4e6eb] hover:text-[#1877f2] dark-mode:hover:text-[#1877f2] transition-colors relative">
            Notifications
            <span className="absolute -top-2 -right-4 bg-[#dc3545] text-white text-xs px-1.5 py-0.5 rounded-full">3</span>
          </Link>
          <Link to="/messages" className="no-underline text-[#050505] dark-mode:text-[#e4e6eb] hover:text-[#1877f2] dark-mode:hover:text-[#1877f2] transition-colors">
            Messages
          </Link>
        </nav>

        <div className="flex items-center gap-2 md:gap-4">
          <div className="hidden sm:block">
            <input
              type="text"
              placeholder="Search..."
              className="px-4 py-2 border border-[#e4e6eb] dark-mode:border-[#4e4f50] dark-mode:bg-[#3a3b3c] dark-mode:text-[#e4e6eb] rounded-full focus:outline-none focus:border-[#1877f2] min-w-[200px]"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <button
            onClick={toggleDarkMode}
            className="bg-transparent border-none text-xl cursor-pointer p-2 rounded-full transition-colors hover:bg-[#f0f2f5] dark-mode:hover:bg-[#3a3b3c]"
            aria-label="Toggle dark mode"
          >
            {darkMode ? '☀️' : '🌙'}
          </button>

          <div className="hidden sm:block">
            <img
              src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop"
              alt="User"
              className="w-8 h-8 rounded-full cursor-pointer"
            />
          </div>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden bg-transparent border-none text-2xl cursor-pointer p-2 rounded-full transition-colors hover:bg-[#f0f2f5] dark-mode:hover:bg-[#3a3b3c] text-[#050505] dark-mode:text-[#e4e6eb]"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? '✕' : '☰'}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden absolute top-16 left-0 right-0 bg-white dark-mode:bg-[#242526] shadow-lg border-t border-[#e4e6eb] dark-mode:border-[#3e4042]">
          <nav className="flex flex-col p-4">
            <Link 
              to="/" 
              className="no-underline text-[#050505] dark-mode:text-[#e4e6eb] hover:text-[#1877f2] dark-mode:hover:text-[#1877f2] py-3 border-b border-[#e4e6eb] dark-mode:border-[#3e4042]"
              onClick={() => setMobileMenuOpen(false)}
            >
              🏠 Home
            </Link>
            <Link 
              to="/profile" 
              className="no-underline text-[#050505] dark-mode:text-[#e4e6eb] hover:text-[#1877f2] dark-mode:hover:text-[#1877f2] py-3 border-b border-[#e4e6eb] dark-mode:border-[#3e4042]"
              onClick={() => setMobileMenuOpen(false)}
            >
              👤 Profile
            </Link>
            <Link 
              to="/notifications" 
              className="no-underline text-[#050505] dark-mode:text-[#e4e6eb] hover:text-[#1877f2] dark-mode:hover:text-[#1877f2] py-3 border-b border-[#e4e6eb] dark-mode:border-[#3e4042] flex justify-between"
              onClick={() => setMobileMenuOpen(false)}
            >
              <span>🔔 Notifications</span>
              <span className="bg-[#dc3545] text-white text-xs px-2 py-1 rounded-full">3</span>
            </Link>
            <Link 
              to="/messages" 
              className="no-underline text-[#050505] dark-mode:text-[#e4e6eb] hover:text-[#1877f2] dark-mode:hover:text-[#1877f2] py-3"
              onClick={() => setMobileMenuOpen(false)}
            >
              💬 Messages
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}

export default Header;